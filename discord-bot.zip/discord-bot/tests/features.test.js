'use strict';

const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bot-featuretest-'));
process.env.DB_PATH = path.join(dir, 'test.db');
process.env.LOG_LEVEL = 'error';

const test = require('node:test');
const assert = require('node:assert/strict');
const db = require('../src/database');
const settings = require('../src/services/settings');
const gw = require('../src/services/giveaways');
const apps = require('../src/services/applications');
const tv = require('../src/services/tempvoice');

test.before(() => db.open());
test.after(() => { db.close(); fs.rmSync(dir, { recursive: true, force: true }); });

const G = '700000000000000001';

// ---- fakes -----------------------------------------------------------------------------------------
function fakeWorld({ present = [], roles = {} } = {}) {
  const sent = [];
  const edits = [];
  const message = { id: 'msg1', edit: async (p) => { edits.push(p); } };
  const channel = {
    isTextBased: () => true,
    permissionsFor: () => ({ has: () => true }),
    messages: { fetch: async () => message },
    send: async (p) => { sent.push(p); return { id: 'ann' }; },
  };
  const guild = {
    id: G, members: {
      me: {},
      fetch: async (id) => (present.includes(id) ? { id, user: { bot: false }, roles: { cache: { has: (r) => (roles[id] ?? []).includes(r) } } } : Promise.reject(new Error('gone'))),
    },
  };
  const client = { guilds: { cache: new Map([[G, guild]]) }, channels: { cache: new Map([['c1', channel]]), fetch: async () => channel } };
  return { client, sent, edits };
}

function newGiveaway(extra = {}) {
  const id = db.run(
    'INSERT INTO giveaways (guild_id, channel_id, message_id, host_id, prize, winner_count, ends_at, required_role_id, min_level, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
    G, 'c1', 'msg1', 'host', extra.prize ?? 'Nitro', extra.winners ?? 2, extra.endsAt ?? Date.now() - 1000, extra.role ?? null, extra.minLevel ?? 0, Date.now(),
  ).lastInsertRowid;
  for (const u of extra.entries ?? []) db.run('INSERT INTO giveaway_entries (giveaway_id, user_id, entered_at) VALUES (?,?,?)', id, u, Date.now());
  return Number(id);
}

// ---- giveaways -------------------------------------------------------------------------------------
test('pickRandom: unique, bounded, never invents entries', () => {
  const pool = ['a', 'b', 'c', 'd'];
  for (let i = 0; i < 50; i += 1) {
    const picked = gw.pickRandom(pool, 3);
    assert.equal(picked.length, 3);
    assert.equal(new Set(picked).size, 3);
    assert.ok(picked.every((p) => pool.includes(p)));
  }
  assert.equal(gw.pickRandom(pool, 10).length, 4);
  assert.deepEqual(gw.pickRandom([], 2), []);
  assert.deepEqual(pool, ['a', 'b', 'c', 'd'], 'input must not be modified');
});

test('entry requirements: ended, role, level', () => {
  const id = newGiveaway({ endsAt: Date.now() + 60_000, role: 'r1', minLevel: 3 });
  const row = gw.get(id);
  const member = (roles) => ({ id: 'u1', roles: { cache: { has: (r) => roles.includes(r) } } });
  assert.match(gw.entryProblem(row, member([])), /role/);
  assert.match(gw.entryProblem(row, member(['r1'])), /level/);
  db.run('INSERT INTO levels (guild_id, user_id, xp, level) VALUES (?, ?, ?, ?)', G, 'u1', 100_000, 20);
  assert.equal(gw.entryProblem(row, member(['r1'])), null);
  assert.match(gw.entryProblem({ ...row, status: 'ended' }, member(['r1'])), /ended/);
  assert.match(gw.entryProblem({ ...row, ends_at: Date.now() - 1 }, member(['r1'])), /ended/);
});

test('ending a giveaway picks only valid entrants, once', async () => {
  const id = newGiveaway({ winners: 2, entries: ['u1', 'u2', 'u3', 'gone'] });
  const { client, sent, edits } = fakeWorld({ present: ['u1', 'u2', 'u3'] });
  const winners = await gw.end(client, id);
  assert.equal(winners.length, 2);
  assert.ok(winners.every((w) => ['u1', 'u2', 'u3'].includes(w)));
  assert.equal(gw.get(id).status, 'ended');
  assert.deepEqual(JSON.parse(gw.get(id).winner_ids), winners);
  assert.equal(edits.length, 1);
  assert.match(sent[0].content, /Congratulations/);
  assert.deepEqual(sent[0].allowedMentions.users, winners);
  assert.equal(await gw.end(client, id), null, 'a second end must do nothing');
  assert.equal(sent.length, 1);
});

test('required role is checked again when the giveaway ends', async () => {
  const id = newGiveaway({ winners: 3, role: 'vip', entries: ['u1', 'u2'] });
  const { client } = fakeWorld({ present: ['u1', 'u2'], roles: { u1: ['vip'] } });
  assert.deepEqual(await gw.end(client, id), ['u1']);
});

test('no entries and cancelled giveaways', async () => {
  const empty = newGiveaway({ entries: [] });
  const world = fakeWorld();
  assert.deepEqual(await gw.end(world.client, empty), []);
  assert.match(world.sent[0].content, /Nobody could win/);
  const cancelled = newGiveaway({ entries: ['u1'] });
  const w2 = fakeWorld({ present: ['u1'] });
  assert.deepEqual(await gw.end(w2.client, cancelled, { cancel: true }), []);
  assert.equal(gw.get(cancelled).status, 'cancelled');
  assert.equal(w2.sent.length, 0, 'cancelling announces nothing');
});

test('reroll never repeats a winner', async () => {
  const id = newGiveaway({ winners: 1, entries: ['u1', 'u2', 'u3'] });
  const { client } = fakeWorld({ present: ['u1', 'u2', 'u3'] });
  const first = await gw.end(client, id);
  const second = await gw.reroll(client, id, 1);
  const third = await gw.reroll(client, id, 1);
  assert.equal(second.length, 1);
  assert.equal(third.length, 1);
  assert.equal(new Set([...first, ...second, ...third]).size, 3);
  assert.deepEqual(await gw.reroll(client, id, 1), [], 'everybody has won already');
});

// ---- applications ------------------------------------------------------------------------------------
test('applications: who may apply', () => {
  const guild = { id: G, channels: { cache: new Map([['review', {}]]) } };
  assert.match(apps.applyProblem(guild, 'u9'), /closed/);
  settings.set(G, 'applications.enabled', true);
  assert.match(apps.applyProblem(guild, 'u9'), /not fully set up/);
  settings.set(G, 'applications.reviewChannelId', 'review');
  assert.equal(apps.applyProblem(guild, 'u9'), null);

  const id = db.run('INSERT INTO applications (guild_id, user_id, answers, created_at) VALUES (?,?,?,?)', G, 'u9', '[]', Date.now()).lastInsertRowid;
  assert.match(apps.applyProblem(guild, 'u9'), /waiting for review/);
  db.run("UPDATE applications SET status = 'rejected', decided_at = ? WHERE id = ?", Date.now(), id);
  assert.match(apps.applyProblem(guild, 'u9'), /apply again/);
  settings.set(G, 'applications.cooldownHours', 0);
  assert.equal(apps.applyProblem(guild, 'u9'), null);
  db.run("UPDATE applications SET status = 'accepted' WHERE id = ?", id);
  assert.match(apps.applyProblem(guild, 'u9'), /already accepted/);
});

test('applications: review message follows the status', () => {
  const id = db.run('INSERT INTO applications (guild_id, user_id, answers, created_at) VALUES (?,?,?,?)', G, 'u5', JSON.stringify([{ q: 'Why?', a: 'Because' }]), Date.now()).lastInsertRowid;
  const view = apps.renderReview(apps.get(id), { username: 'x' }, settings.view(G).applications);
  assert.equal(view.embeds.length, 1);
  assert.equal(view.components.length, 1);
});

// ---- temporary voice -----------------------------------------------------------------------------------------
test('room names are one safe line of 1-100 characters', () => {
  assert.equal(tv.cleanName('  hello\n\nworld  '), 'hello world');
  assert.ok(!tv.cleanName('@everyone party').includes('@'));
  assert.equal(tv.cleanName('   ', 'fallback'), 'fallback');
  assert.equal(tv.cleanName('x'.repeat(300)).length, 100);
});

test('empty rooms are removed, occupied or unknown channels are not', async () => {
  const deleted = [];
  const mk = (id, humans) => ({
    id, type: 2, members: { filter: (fn) => { const list = humans.filter((m) => fn(m)); return { size: list.length }; } },
    delete: async () => { deleted.push(id); },
  });
  db.run('INSERT INTO temp_voice (channel_id, guild_id, owner_id, created_at) VALUES (?,?,?,?)', 'v1', G, 'u1', Date.now());
  db.run('INSERT INTO temp_voice (channel_id, guild_id, owner_id, created_at) VALUES (?,?,?,?)', 'v2', G, 'u1', Date.now());
  await tv.cleanupIfEmpty(mk('v1', [{ user: { bot: false } }]));
  assert.deepEqual(deleted, []);
  await tv.cleanupIfEmpty(mk('v2', [{ user: { bot: true } }])); // only a bot left
  assert.deepEqual(deleted, ['v2']);
  assert.ok(!tv.getRoom('v2'));
  await tv.cleanupIfEmpty(mk('not-a-room', [])); // channels we did not create are never touched
  assert.deepEqual(deleted, ['v2']);
});

// ---- random drops ----------------------------------------------------------------------------------
test('drops: coin and item rewards, cooldown, channel filter, notice deleted', async () => {
  const drops = require('../src/services/drops');
  const eco = require('../src/services/economy');
  const g = '700000000000000009';
  settings.update(g, (s) => { s.drops.enabled = true; s.drops.chance = 1; s.drops.minCoins = 50; s.drops.maxCoins = 50; s.drops.itemChance = 0; s.drops.deleteAfterSeconds = 3; });
  const sent = [];
  const deleted = [];
  const make = (userId, channelId = 'ch1', content = 'hello there') => ({
    guild: { id: g, members: { me: {} } }, author: { id: userId, bot: false }, channelId, content,
    channel: { permissionsFor: () => ({ has: () => true }), send: async (p) => { sent.push(p); return { delete: async () => { deleted.push(1); } }; } },
  });
  const start = eco.getAccount(g, '111').wallet;
  const r = await drops.handleMessage(make('111'));
  assert.equal(r.kind, 'coins');
  assert.equal(eco.getAccount(g, '111').wallet, start + 50);
  assert.match(sent[0].content, /<@111>/);
  assert.equal(await drops.handleMessage(make('111')), null); // user cooldown
  assert.equal(await drops.handleMessage(make('222', 'ch1', 'hi')), null); // too short
  // item drop
  eco.addItem(g, { name: 'Gem', price: 10 });
  eco.addItem(g, { name: 'VIP', price: 10, roleId: '5' });
  settings.update(g, (s) => { s.drops.itemChance = 1; });
  const it = await drops.handleMessage(make('333'));
  assert.equal(it.kind, 'item');
  assert.equal(it.item.name, 'Gem'); // role items never drop
  assert.equal(eco.inventory(g, '333')[0].quantity, 1);
  // channel filter + disabled economy
  settings.update(g, (s) => { s.drops.channelIds = ['only']; });
  assert.equal(await drops.handleMessage(make('444', 'other')), null);
  assert.ok((await drops.handleMessage(make('444', 'only'))));
});

test('settings.replaceId swaps ids everywhere', () => {
  const g = '700000000000000010';
  settings.update(g, (s) => { s.welcome.channelId = '900'; s.leveling.noXpChannelIds = ['1', '900']; });
  assert.equal(settings.replaceId(g, '900', '901'), 2);
  assert.equal(settings.view(g).welcome.channelId, '901');
  assert.deepEqual(settings.view(g).leveling.noXpChannelIds, ['1', '901']);
  assert.equal(settings.replaceId(g, 'nope', 'x'), 0);
});

// ---- level roles ----------------------------------------------------------------------------------
test('syncLevelRoles grants earned roles and removes the ones no longer earned', async () => {
  const leveling = require('../src/services/leveling');
  const g = '700000000000000011';
  settings.update(g, (s) => { s.leveling.stackRoles = false; s.leveling.levelRoles = [{ level: 1, roleId: 'r1' }, { level: 5, roleId: 'r5' }]; });
  const have = new Set(['r1']);
  const log = [];
  const roleOf = (id) => ({ id, managed: false, position: 1 });
  const member = {
    id: 'u', guild: {
      id: g,
      members: { me: { permissions: { has: () => true }, roles: { highest: { position: 10 } } } },
      roles: { cache: new Map([['r1', roleOf('r1')], ['r5', roleOf('r5')]]) },
    },
    roles: { cache: { has: (id) => have.has(id) }, add: async (r) => { have.add(r.id); log.push(`+${r.id}`); }, remove: async (r) => { have.delete(r.id); log.push(`-${r.id}`); } },
  };
  await leveling.syncLevelRoles(member, 5);
  assert.deepEqual([...have].sort(), ['r5']); // highest only, r1 replaced
  await leveling.syncLevelRoles(member, 0); // XP reset: every level role goes
  assert.deepEqual([...have], []);
  await leveling.syncLevelRoles(member, 1);
  assert.deepEqual([...have], ['r1']);
});

// ---- first-click drops -----------------------------------------------------------------------------
test('drop: only the first claim wins, the timer job never touches it', () => {
  const g = '700000000000000012';
  const id = db.run(
    `INSERT INTO giveaways (guild_id, channel_id, host_id, prize, winner_count, ends_at, created_at, kind) VALUES (?, 'c', 'h', 'Nitro', 1, ?, ?, 'drop')`,
    g, gw.NEVER, Date.now(),
  ).lastInsertRowid;
  assert.equal(db.all("SELECT id FROM giveaways WHERE status = 'active' AND ends_at <= ?", Date.now()).some((r) => r.id === id), false);
  assert.equal(gw.claimDrop(id, 'alice'), true);
  assert.equal(gw.claimDrop(id, 'bob'), false);
  const row = gw.get(id);
  assert.equal(row.status, 'ended');
  assert.deepEqual(gw.winnersOf(row), ['alice']);
  // timed giveaways are never claimable
  const timed = db.run("INSERT INTO giveaways (guild_id, channel_id, host_id, prize, ends_at, created_at) VALUES (?, 'c', 'h', 'x', ?, ?)", g, Date.now() + 1e6, Date.now()).lastInsertRowid;
  assert.equal(gw.claimDrop(timed, 'alice'), false);
});

// ---- security --------------------------------------------------------------------------------------
test('security helpers: counter window, alt detection, trust', () => {
  const sec = require('../src/services/security');
  const c = new sec.Counter();
  assert.equal(c.hit('k', 1000, 0), 1);
  assert.equal(c.hit('k', 1000, 500), 2);
  assert.equal(c.hit('k', 1000, 1600), 1); // both earlier hits left the window
  assert.equal(c.hit('k', 1000, 1700), 2);
  const now = Date.UTC(2026, 10, 1);
  const young = { createdTimestamp: now - 2 * 86_400_000, avatar: 'abc' };
  const old = { createdTimestamp: now - 90 * 86_400_000, avatar: null };
  assert.match(sec.altReason(young, { altMinAgeDays: 7, altNoAvatar: false }, now), /day/);
  assert.equal(sec.altReason(old, { altMinAgeDays: 7, altNoAvatar: false }, now), null);
  assert.match(sec.altReason(old, { altMinAgeDays: 7, altNoAvatar: true }, now), /profile picture/);
  assert.equal(sec.altReason(young, { altMinAgeDays: 0, altNoAvatar: false }, now), null);
});

test('security: nuke protection punishes at the limit, never trusted members or the bot', async () => {
  const sec = require('../src/services/security');
  const g = '700000000000000013';
  settings.update(g, (s) => { s.security.enabled = true; s.security.nukeLimit = 3; s.security.nukeSeconds = 30; s.security.nukeAction = 'kick'; s.security.trustedRoleIds = ['trusted']; });
  const sent = [];
  const kicked = [];
  let guild;
  const mk = (id, roles = []) => ({ id, get guild() { return guild; }, kickable: true, roles: { cache: { has: (r) => roles.includes(r) } }, kick: async () => { kicked.push(id); } });
  const members = { evil: mk('evil'), friend: mk('friend', ['trusted']) };
  guild = {
    id: g, ownerId: 'owner', client: { user: { id: 'bot' } },
    members: { me: { permissions: { has: () => true } }, fetch: async (id) => members[id] ?? null },
    channels: { fetch: async () => ({ isTextBased: () => true, send: async (p) => sent.push(p) }) },
  };
  settings.update(g, (s) => { s.security.alertChannelId = 'alerts'; });
  assert.equal(await sec.registerDestructive(guild, { id: 'evil' }, 'a'), false);
  assert.equal(await sec.registerDestructive(guild, { id: 'evil' }, 'b'), false);
  assert.equal(await sec.registerDestructive(guild, { id: 'evil' }, 'c'), true);
  assert.deepEqual(kicked, ['evil']);
  assert.equal(sent.length, 1);
  for (let i = 0; i < 10; i++) assert.equal(await sec.registerDestructive(guild, { id: 'friend' }, 'x'), false);
  for (let i = 0; i < 10; i++) assert.equal(await sec.registerDestructive(guild, { id: 'owner' }, 'x'), false);
  for (let i = 0; i < 10; i++) assert.equal(await sec.registerDestructive(guild, { id: 'bot' }, 'x'), false);
  assert.deepEqual(kicked, ['evil']);
  settings.update(g, (s) => { s.security.enabled = false; });
  assert.equal(await sec.registerDestructive(guild, { id: 'stranger' }, 'x'), false); // module off
});

// ---- backups ---------------------------------------------------------------------------------------
test('backup: snapshot, save/list/prune and restore only what is missing', async () => {
  const backups = require('../src/services/backups');
  const g = '700000000000000014';
  settings.update(g, (s) => { s.welcome.channelId = 'oldchan'; s.security.backupKeep = 2; });
  const ids = { n: 0 };
  const bits = (n) => ({ bitfield: BigInt(n) });
  const roleStore = new Map([['r_mod', { id: 'r_mod', name: 'Mod', color: 1, hoist: true, mentionable: false, permissions: bits(8), position: 3, managed: false }]]);
  const chanStore = new Map([['oldchan', { id: 'oldchan', name: 'welcome', type: 0, parentId: null, rawPosition: 1, topic: 't', nsfw: false, rateLimitPerUser: 0, bitrate: null, userLimit: 0,
    permissionOverwrites: { cache: new Map([['r_mod', { id: 'r_mod', type: 0, allow: bits(1024n), deny: bits(0n) }]]) } }]]);
  const member = { id: 'u1', user: { bot: false }, roles: { cache: new Map([['r_mod', {}]]), add: async (r) => { member.added = r; } } };
  const created = { roles: [], channels: [] };
  const guild = {
    id: g, name: 'Test',
    members: { me: { permissions: { has: () => true, bitfield: ~0n }, roles: { highest: { position: 50 } } }, cache: new Map([['u1', member]]), fetch: async () => {} },
    roles: { cache: Object.assign(roleStore, { find: (fn) => [...roleStore.values()].find(fn) }), fetch: async () => {},
      create: async (o) => { const id = `nr${++ids.n}`; const r = { id, ...o, permissions: bits(o.permissions), position: 1, managed: false }; roleStore.set(id, r); created.roles.push(o); return r; } },
    channels: { cache: Object.assign(chanStore, { find: (fn) => [...chanStore.values()].find(fn) }), fetch: async () => {},
      create: async (o) => { const id = `nc${++ids.n}`; const c = { id, ...o, rawPosition: o.position, parentId: o.parent ?? null, permissionOverwrites: { cache: new Map(o.permissionOverwrites.map((w) => [w.id, { ...w, allow: bits(w.allow), deny: bits(w.deny) }])) } }; chanStore.set(id, c); created.channels.push(o); return c; } },
  };
  const { id, data } = await backups.create(guild, { name: 'first', createdBy: 'u' });
  assert.equal(data.roles.length, 1);
  assert.equal(data.channels.length, 1);
  assert.deepEqual(data.memberRoles, { u1: ['r_mod'] });
  assert.equal(backups.list(g).length, 1);
  // everything exists: restore changes nothing
  const same = await backups.restore(guild, data, { members: true });
  assert.equal(created.roles.length + created.channels.length, 0);
  assert.equal(same.rolesMatched, 1);
  // a nuke deletes both
  roleStore.clear(); chanStore.clear(); member.roles.cache.clear();
  const r = await backups.restore(guild, data, { members: true });
  assert.equal(r.rolesCreated, 1);
  assert.equal(r.channelsCreated, 1);
  assert.equal(created.channels[0].permissionOverwrites[0].id, [...roleStore.keys()][0]); // overwrite points at the NEW role
  assert.equal(member.added[0], [...roleStore.keys()][0]);
  assert.equal(r.settingsRepointed, 1);
  assert.equal(settings.view(g).welcome.channelId, [...chanStore.keys()][0]); // bot setting follows the new channel
  // auto backups are pruned to backupKeep
  for (let i = 0; i < 4; i++) await backups.create(guild, { kind: 'auto' });
  assert.equal(backups.list(g).filter((b) => b.kind === 'auto').length, 2);
  assert.ok(backups.getOwn(g, id));
});

test('automod spam ignores configured channels', async () => {
  const automod = require('../src/services/automod');
  const cfg = settings.view('700000000000000015').moderation.automod;
  assert.deepEqual(cfg.spam.ignoredChannelIds, []);
});

// ---- custom commands -------------------------------------------------------------------------------
test('custom commands: validation, limit of 25, rendering and chat lookup', () => {
  const cc = require('../src/services/customCommands');
  const prefixService = require('../src/services/prefix');
  const g = '700000000000000016';
  const builtins = new Map([['ping', {}], ['help', {}]]);
  assert.equal(cc.validateName('!Rules', builtins), 'rules'); // typed with the prefix and capitals
  assert.throws(() => cc.validateName('ping', builtins), /built-in/);
  assert.throws(() => cc.validateName('bad name', builtins), /letters, numbers/);
  assert.throws(() => cc.validateResponse('   '), /empty/);
  assert.throws(() => cc.validateResponse('x'.repeat(1501)), /at most 1500/);
  assert.equal(cc.validateResponse('line1\\nline2'), 'line1\nline2');

  for (let i = 0; i < 25; i++) cc.add(g, `cmd${i}`, 'hi');
  assert.throws(() => cc.add(g, 'one-too-many', 'hi'), /25 custom commands/);
  assert.throws(() => cc.add(g, 'cmd1', 'again'), /already exists/);
  assert.equal(cc.count(g), 25);
  assert.equal(cc.count('700000000000000017'), 0); // limits are per server

  cc.edit(g, 'cmd1', { response: 'Hello {username} in {channel}: {args}', embed: true });
  const row = cc.get(g, 'CMD1');
  const message = { author: { id: 'u1', username: 'asa' }, member: null, channelId: 'c9', guild: { name: 'Srv' } };
  const out = cc.render(row, message, 'extra @everyone');
  assert.equal(out.embeds.length, 1);
  assert.deepEqual(out.allowedMentions.parse, []); // nothing can ping everyone
  assert.deepEqual(out.allowedMentions.users, ['u1']);
  const plain = cc.render({ ...row, use_embed: 0 }, message, 'x');
  assert.equal(plain.content, 'Hello asa in <#c9>: x');
  assert.equal(cc.remove(g, 'cmd1'), true);
  assert.equal(cc.remove(g, 'cmd1'), false);

  // chat lookup: built-ins win, unknown words fall back to the server's custom commands
  const client = { user: { id: '999' }, commands: builtins };
  const msg = (content, guildId = g) => ({ content, guild: { id: guildId }, guildId });
  const hit = prefixService.parseInvocation(msg('!cmd2 some args'), client);
  assert.equal(hit.custom.name, 'cmd2');
  assert.equal(hit.args, 'some args');
  assert.equal(prefixService.parseInvocation(msg('!nothing'), client), null);
  assert.equal(prefixService.parseInvocation(msg('!cmd2', '700000000000000017'), client), null); // other server
  assert.ok(prefixService.parseInvocation(msg('!ping'), client).command);
});
