'use strict';

const { PermissionFlagsBits: P, ChannelType: CT, OverwriteType } = require('discord.js');
const db = require('../database');
const settings = require('./settings');
const embeds = require('../utils/embeds');
const audit = require('./audit');
const logger = require('../utils/logger');
const { UserError } = require('../utils/errors');
const { confirm } = require('../utils/confirm');
const { formatNumber, truncate } = require('../utils/text');
const { ts } = require('../utils/time');

const MAX_MANUAL = 10;
const MAX_MEMBERS = 5000; // members whose role list is stored
const RESTORE_BUDGET_MS = 12 * 60_000; // interaction tokens live 15 minutes
const CHANNEL_TYPES = new Set([CT.GuildText, CT.GuildVoice, CT.GuildCategory, CT.GuildAnnouncement, CT.GuildStageVoice, CT.GuildForum]);
const TEXTY = new Set([CT.GuildText, CT.GuildAnnouncement, CT.GuildForum]);
const VOICEY = new Set([CT.GuildVoice, CT.GuildStageVoice]);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---- snapshot --------------------------------------------------------------------------------

/** Reads everything restorable from a guild into plain JSON. */
async function snapshot(guild, { members = true } = {}) {
  await guild.roles.fetch().catch(() => {});
  await guild.channels.fetch().catch(() => {});
  const roles = [...guild.roles.cache.values()]
    .filter((r) => r.id !== guild.id)
    .map((r) => ({
      id: r.id, name: r.name, color: r.color, hoist: r.hoist, mentionable: r.mentionable,
      permissions: r.permissions.bitfield.toString(), position: r.position, managed: r.managed,
    }));
  const channels = [...guild.channels.cache.values()]
    .filter((c) => CHANNEL_TYPES.has(c.type))
    .map((c) => ({
      id: c.id, name: c.name, type: c.type, parentId: c.parentId ?? null, position: c.rawPosition ?? c.position ?? 0,
      topic: c.topic ?? null, nsfw: !!c.nsfw, rateLimitPerUser: c.rateLimitPerUser ?? 0,
      bitrate: c.bitrate ?? null, userLimit: c.userLimit ?? 0,
      overwrites: [...(c.permissionOverwrites?.cache.values() ?? [])].map((o) => ({ id: o.id, type: o.type, allow: o.allow.bitfield.toString(), deny: o.deny.bitfield.toString() })),
    }));
  let memberRoles = {};
  let memberCount = 0;
  if (members) {
    await guild.members.fetch().catch((err) => logger.debug(`Backup member fetch failed: ${err.message}`));
    const keepable = new Set(roles.filter((r) => !r.managed).map((r) => r.id));
    for (const m of guild.members.cache.values()) {
      if (memberCount >= MAX_MEMBERS) break;
      if (m.user.bot) continue;
      const list = [...m.roles.cache.keys()].filter((id) => keepable.has(id));
      if (list.length) { memberRoles[m.id] = list; memberCount += 1; }
    }
  }
  return { version: 1, guildName: guild.name, takenAt: Date.now(), roles, channels, memberRoles };
}

// ---- storage ---------------------------------------------------------------------------------

function save(guild, { kind = 'manual', name, createdBy = null, data }) {
  const id = db.run(
    `INSERT INTO backups (guild_id, name, kind, data, roles, channels, members, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    guild.id, truncate(name || (kind === 'auto' ? 'Automatic backup' : 'Backup'), 60), kind, JSON.stringify(data),
    data.roles.length, data.channels.length, Object.keys(data.memberRoles).length, createdBy, Date.now(),
  ).lastInsertRowid;
  if (kind === 'auto') {
    const keep = settings.view(guild.id).security.backupKeep;
    const old = db.all("SELECT id FROM backups WHERE guild_id = ? AND kind = 'auto' ORDER BY id DESC LIMIT -1 OFFSET ?", guild.id, keep);
    for (const o of old) db.run('DELETE FROM backups WHERE id = ?', o.id);
  }
  return id;
}

const list = (guildId) => db.all('SELECT id, name, kind, roles, channels, members, created_by, created_at FROM backups WHERE guild_id = ? ORDER BY id DESC', guildId);
const getOwn = (guildId, id) => db.get('SELECT * FROM backups WHERE guild_id = ? AND id = ?', guildId, id);
const latestAuto = (guildId) => db.get("SELECT created_at FROM backups WHERE guild_id = ? AND kind = 'auto' ORDER BY id DESC LIMIT 1", guildId);

async function create(guild, opts = {}) {
  if (opts.kind !== 'auto' && db.get("SELECT COUNT(*) AS n FROM backups WHERE guild_id = ? AND kind = 'manual'", guild.id).n >= MAX_MANUAL) {
    throw new UserError(`You can keep at most ${MAX_MANUAL} manual backups. Delete one with \`/config backup action:delete id:…\`.`);
  }
  const data = await snapshot(guild, { members: opts.members ?? true });
  return { id: save(guild, { ...opts, data }), data };
}

// ---- restore ---------------------------------------------------------------------------------

/** Permission bits the bot may hand out: everything when it is an administrator, otherwise only its own. */
function grantable(guild) {
  const me = guild.members.me;
  return me.permissions.has(P.Administrator) ? ~0n : me.permissions.bitfield;
}

/**
 * Re-creates what is missing. Nothing is ever deleted or changed on existing roles/channels.
 * @param {{ members?: boolean, onProgress?: (text: string) => Promise<void> }} opts
 */
async function restore(guild, data, { members = false, onProgress = async () => {} } = {}) {
  const started = Date.now();
  const me = guild.members.me;
  const mask = grantable(guild);
  const report = { rolesCreated: 0, rolesMatched: 0, rolesFailed: 0, rolesMasked: 0, channelsCreated: 0, channelsMatched: 0, channelsFailed: 0, membersUpdated: 0, membersSkipped: 0, settingsRepointed: 0, stoppedEarly: false };
  const roleMap = new Map(); // old id -> id in the guild now
  const chanMap = new Map();

  await guild.roles.fetch().catch(() => {});
  await guild.channels.fetch().catch(() => {});
  if (members) await guild.members.fetch().catch(() => {});

  // 1. roles — highest first, because every new role lands at the bottom
  const usedRoles = new Set();
  const roles = [...data.roles].filter((r) => !r.managed).sort((a, b) => b.position - a.position);
  for (const r of roles) {
    const same = guild.roles.cache.get(r.id) ?? guild.roles.cache.find((x) => !usedRoles.has(x.id) && !x.managed && x.name === r.name);
    if (same) { roleMap.set(r.id, same.id); usedRoles.add(same.id); report.rolesMatched += 1; continue; }
    const wanted = BigInt(r.permissions);
    const granted = wanted & mask;
    try {
      const role = await guild.roles.create({
        name: r.name, color: r.color, hoist: r.hoist, mentionable: r.mentionable, permissions: granted, reason: 'Server backup restore',
      });
      roleMap.set(r.id, role.id);
      usedRoles.add(role.id);
      report.rolesCreated += 1;
      if (granted !== wanted) report.rolesMasked += 1;
    } catch (err) {
      report.rolesFailed += 1;
      logger.warn(`Restore: role "${r.name}" failed: ${err.message}`);
    }
  }
  await onProgress(`Roles: ${report.rolesCreated} created, ${report.rolesMatched} already existed. Now channels…`);

  // 2. channels — categories first
  const usedChannels = new Set();
  const order = [...data.channels].sort((a, b) => (a.type === CT.GuildCategory ? 0 : 1) - (b.type === CT.GuildCategory ? 0 : 1) || a.position - b.position);
  const overwritesFor = (c, limit) => c.overwrites.flatMap((o) => {
    let id = o.id;
    if (o.type === OverwriteType.Role) {
      if (o.id === guild.id) id = guild.id; // @everyone
      else if (roleMap.has(o.id)) id = roleMap.get(o.id);
      else return [];
    } else if (!guild.members.cache.has(o.id)) return [];
    return [{ id, type: o.type, allow: BigInt(o.allow) & limit, deny: BigInt(o.deny) & limit }];
  });

  for (const c of order) {
    const parent = c.parentId ? (chanMap.get(c.parentId) ?? null) : null;
    const same = guild.channels.cache.get(c.id)
      ?? guild.channels.cache.find((x) => !usedChannels.has(x.id) && x.type === c.type && x.name === c.name && (x.parentId ?? null) === parent);
    if (same) { chanMap.set(c.id, same.id); usedChannels.add(same.id); report.channelsMatched += 1; continue; }

    const base = {
      name: c.name, type: c.type, parent: parent ?? undefined, position: c.position, reason: 'Server backup restore',
      ...(TEXTY.has(c.type) ? { topic: c.topic ?? undefined, nsfw: c.nsfw } : {}),
      ...(c.type === CT.GuildText || c.type === CT.GuildForum ? { rateLimitPerUser: c.rateLimitPerUser } : {}),
      ...(VOICEY.has(c.type) ? { bitrate: c.bitrate ?? undefined, userLimit: c.userLimit } : {}),
    };
    let created = null;
    for (const limit of [~0n, mask]) { // first with the original permissions, then only what the bot may grant
      try {
        created = await guild.channels.create({ ...base, permissionOverwrites: overwritesFor(c, limit) });
        break;
      } catch (err) {
        logger.warn(`Restore: channel "${c.name}" failed (${limit === mask ? 'masked' : 'full'}): ${err.message}`);
        if (limit === mask) break;
      }
    }
    if (created) {
      chanMap.set(c.id, created.id);
      usedChannels.add(created.id);
      report.channelsCreated += 1;
    } else {
      report.channelsFailed += 1;
    }
  }
  await onProgress(`Channels: ${report.channelsCreated} created, ${report.channelsMatched} already existed.${members ? ' Now member roles…' : ''}`);

  // 3. the bot's own settings pointed at the old ids: repoint them
  for (const [oldId, newId] of [...roleMap, ...chanMap]) {
    if (oldId !== newId) report.settingsRepointed += settings.replaceId(guild.id, oldId, newId);
  }

  // 4. give members their roles back
  if (members) {
    const botTop = me.roles.highest.position;
    let done = 0;
    for (const [userId, ids] of Object.entries(data.memberRoles ?? {})) {
      if (Date.now() - started > RESTORE_BUDGET_MS) { report.stoppedEarly = true; break; }
      const member = guild.members.cache.get(userId);
      if (!member) { report.membersSkipped += 1; continue; }
      const add = ids
        .map((id) => roleMap.get(id))
        .filter((id) => id && !member.roles.cache.has(id) && (guild.roles.cache.get(id)?.position ?? 0) < botTop);
      if (add.length) {
        try { await member.roles.add(add, 'Server backup restore'); report.membersUpdated += 1; } catch { report.membersSkipped += 1; }
      }
      done += 1;
      if (done % 50 === 0) await onProgress(`Member roles: ${done} members checked…`);
    }
  }
  return report;
}

// ---- command UI (/config backup) -------------------------------------------------------------

const ACTIONS = ['create', 'list', 'info', 'delete', 'restore'];

function addOptions(sub) {
  return sub
    .addStringOption((o) => o.setName('action').setDescription('What to do').setRequired(true)
      .addChoices(...ACTIONS.map((a) => ({ name: a, value: a }))))
    .addIntegerOption((o) => o.setName('id').setDescription('Backup number (for info, delete, restore)').setMinValue(1))
    .addStringOption((o) => o.setName('name').setDescription('Name for a new backup').setMaxLength(60))
    .addBooleanOption((o) => o.setName('members').setDescription('Include / restore each member\'s roles (default: yes for create, no for restore)'));
}

const line = (b) => `**#${b.id}** · ${b.kind === 'auto' ? '🤖' : '👤'} ${truncate(b.name, 40)} · ${b.roles} roles · ${b.channels} channels · ${b.members} members · ${ts(b.created_at, 'R')}`;

async function run(interaction) {
  const { guild } = interaction;
  if (!interaction.memberPermissions.has(P.Administrator)) throw new UserError('Backups contain your whole server layout, so only **Administrators** can manage them.');
  const action = interaction.options.getString('action', true);
  const ephemeral = { flags: 64, allowedMentions: { parse: [] } };

  if (action === 'list') {
    const rows = list(guild.id);
    await interaction.reply({ embeds: [embeds.base('💾 Backups', rows.length ? rows.slice(0, 20).map(line).join('\n') : 'No backups yet. Make one with `/config backup action:create`.')], ...ephemeral });
    return;
  }

  if (action === 'create') {
    const me = guild.members.me;
    if (!me.permissions.has(P.ManageRoles)) throw new UserError('I need at least **Manage Roles** and **Manage Channels** to be able to restore later.');
    await interaction.deferReply({ flags: 64 });
    const { id, data } = await create(guild, { name: interaction.options.getString('name'), createdBy: interaction.user.id, members: interaction.options.getBoolean('members') ?? true });
    audit.record(guild.id, interaction.user.id, 'backup.create', String(id));
    await interaction.editReply({ embeds: [embeds.success(`Backup **#${id}** saved: ${data.roles.length} roles, ${data.channels.length} channels, ${Object.keys(data.memberRoles).length} members' roles.\nRestore it with \`/config backup action:restore id:${id}\`.`)] });
    return;
  }

  const id = interaction.options.getInteger('id');
  if (!id) throw new UserError('Give the backup number with `id:`. See `/config backup action:list`.');
  const row = getOwn(guild.id, id);
  if (!row) throw new UserError('I could not find that backup in this server.');

  if (action === 'info') {
    const data = JSON.parse(row.data);
    const cats = data.channels.filter((c) => c.type === CT.GuildCategory).length;
    await interaction.reply({
      embeds: [embeds.base(`💾 Backup #${row.id}`, `${line(row)}\nServer name then: **${truncate(data.guildName, 60)}**\n${data.channels.length - cats} channels in ${cats} categories.`)],
      ...ephemeral,
    });
    return;
  }

  if (action === 'delete') {
    db.run('DELETE FROM backups WHERE id = ? AND guild_id = ?', row.id, guild.id);
    audit.record(guild.id, interaction.user.id, 'backup.delete', String(row.id));
    await interaction.reply({ embeds: [embeds.success(`Deleted backup #${row.id}.`)], ...ephemeral });
    return;
  }

  // restore
  const me = guild.members.me;
  if (!me.permissions.has([P.ManageRoles, P.ManageChannels])) throw new UserError('I need **Manage Roles** and **Manage Channels** to restore.');
  const members = interaction.options.getBoolean('members') ?? false;
  const ok = await confirm(interaction, {
    title: '♻️ Restore backup?',
    description: `Backup **#${row.id}** (${ts(row.created_at, 'f')}) will re-create the roles and channels that are **missing** now${members ? ' and give members their roles back' : ''}.\n`
      + 'Nothing existing is deleted or edited. Messages, webhooks, emojis and bans are **not** part of a backup. Roles above mine cannot be given back, and permissions I do not have are left out of re-created roles.',
    confirmLabel: 'Restore',
    danger: false,
    timeout: 60_000,
  });
  if (!ok) return;
  audit.record(guild.id, interaction.user.id, 'backup.restore', String(row.id), members ? 'with members' : 'layout only');
  const data = JSON.parse(row.data);
  const edit = (text) => interaction.editReply({ embeds: [embeds.info(`⏳ ${text}`, 'Restoring…')], components: [] }).catch(() => {});
  await edit('Starting…');
  const r = await restore(guild, data, { members, onProgress: edit });
  const lines = [
    `**Roles:** ${r.rolesCreated} created, ${r.rolesMatched} already there${r.rolesFailed ? `, ⚠️ ${r.rolesFailed} failed` : ''}${r.rolesMasked ? `, ${r.rolesMasked} created with fewer permissions than before (I cannot grant what I do not have)` : ''}`,
    `**Channels:** ${r.channelsCreated} created, ${r.channelsMatched} already there${r.channelsFailed ? `, ⚠️ ${r.channelsFailed} failed` : ''}`,
    members ? `**Member roles:** ${formatNumber(r.membersUpdated)} members updated${r.membersSkipped ? `, ${r.membersSkipped} skipped (left the server, or a role is above mine)` : ''}${r.stoppedEarly ? '\n⚠️ Stopped early to stay within time; run the restore again to continue.' : ''}` : '**Member roles:** not restored (`members:true` to include them)',
    r.settingsRepointed ? `Updated ${r.settingsRepointed} bot setting(s) that pointed to old channel/role IDs.` : '',
    '\nCheck the channel order and role order; Discord only lets me place new roles at the bottom, so drag them into place if needed.',
  ].filter(Boolean);
  await interaction.editReply({ embeds: [embeds.base('♻️ Restore finished', lines.join('\n'), embeds.COLORS.success)], components: [] }).catch(() => {});
}

module.exports = { snapshot, create, save, restore, list, getOwn, latestAuto, addOptions, run, grantable };
