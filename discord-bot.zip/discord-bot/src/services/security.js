'use strict';

const { PermissionFlagsBits: P, AuditLogEvent, ChannelType } = require('discord.js');
const settings = require('./settings');
const logging = require('./logging');
const mod = require('./moderation');
const embeds = require('../utils/embeds');
const logger = require('../utils/logger');

const cfgOf = (guildId) => settings.view(guildId).security;

const DANGEROUS = [P.Administrator, P.ManageGuild, P.ManageRoles, P.ManageChannels, P.BanMembers, P.KickMembers, P.ModerateMembers, P.ManageWebhooks];

// ---- small helpers (pure, unit-tested) ------------------------------------------------------

/** Sliding-window counter. `hit` records an event and returns how many fall inside the window. */
class Counter {
  constructor() { this.map = new Map(); }

  hit(key, windowMs, now = Date.now()) {
    const list = (this.map.get(key) ?? []).filter((t) => now - t < windowMs);
    list.push(now);
    this.map.set(key, list);
    return list.length;
  }

  clear(key) { this.map.delete(key); }

  sweep(maxAgeMs, now = Date.now()) {
    for (const [k, list] of this.map) {
      const fresh = list.filter((t) => now - t < maxAgeMs);
      if (fresh.length) this.map.set(k, fresh); else this.map.delete(k);
    }
  }
}

/** Why a new member looks like an alt / throw-away account, or null. */
function altReason(user, cfg, now = Date.now()) {
  const ageDays = (now - user.createdTimestamp) / 86_400_000;
  if (cfg.altMinAgeDays > 0 && ageDays < cfg.altMinAgeDays) return `account is only ${ageDays.toFixed(1)} day(s) old`;
  if (cfg.altNoAvatar && !user.avatar) return 'account has no profile picture';
  return null;
}

/** Trusted = server owner, the bot itself, or a holder of a trusted role. */
function isTrusted(guild, member, userId) {
  if (userId === guild.ownerId || userId === guild.client.user.id) return true;
  const ids = cfgOf(guild.id).trustedRoleIds;
  return !!member && ids.some((r) => member.roles.cache.has(r));
}

async function alert(guild, text, title = '🛡️ Security') {
  const e = embeds.base(title, text, embeds.COLORS.danger);
  const id = cfgOf(guild.id).alertChannelId;
  if (id) {
    try {
      const ch = await guild.channels.fetch(id);
      if (ch?.isTextBased()) { await ch.send({ embeds: [e], allowedMentions: { parse: [] } }); return; }
    } catch { /* fall back to the moderation log */ }
  }
  await logging.send(guild, 'moderation', e);
}

/** Missing permissions that make the module only half work. */
function problems(guild) {
  const cfg = cfgOf(guild.id);
  const me = guild.members.me;
  const out = [];
  if (cfg.nukeProtection || cfg.blockBots) {
    if (!me.permissions.has(P.ViewAuditLog)) out.push('I need **View Audit Log** to see who deleted channels/roles or added a bot.');
  }
  if (!me.permissions.has([P.KickMembers, P.BanMembers])) out.push('I need **Kick Members** and **Ban Members** to punish.');
  if (cfg.nukeAction === 'strip' && !me.permissions.has(P.ManageRoles)) out.push('I need **Manage Roles** for the `strip` action. My role must be **above** the roles it removes.');
  if (cfg.restoreChannels && !me.permissions.has(P.ManageChannels)) out.push('I need **Manage Channels** to restore deleted channels.');
  if (cfg.altAction === 'quarantine') {
    const role = cfg.quarantineRoleId && guild.roles.cache.get(cfg.quarantineRoleId);
    if (!role) out.push('`alt_action: quarantine` needs a `quarantine_role` (a role that can only see a "verify" channel).');
    else if (role.position >= me.roles.highest.position) out.push('My highest role must be above the quarantine role.');
  }
  if (!cfg.enabled) out.push('The module is **off**: turn it on with `enabled:true`.');
  return out;
}

// ---- punishing -------------------------------------------------------------------------------

async function punish(member, action, reason) {
  const guild = member.guild;
  const botId = guild.client.user.id;
  try {
    if (action === 'ban' && member.bannable) {
      await member.ban({ reason });
      mod.createCase({ guild, userId: member.id, moderatorId: botId, action: 'ban', reason });
      return 'banned (permanent)';
    }
    if ((action === 'kick' || action === 'ban') && member.kickable) {
      await member.kick(reason);
      mod.createCase({ guild, userId: member.id, moderatorId: botId, action: 'kick', reason });
      return 'kicked';
    }
    if (action === 'strip') {
      const me = guild.members.me;
      const roles = member.roles.cache.filter((r) => r.id !== guild.id && !r.managed
        && DANGEROUS.some((p) => r.permissions.has(p)) && r.position < me.roles.highest.position);
      if (roles.size) {
        await member.roles.remove([...roles.keys()], reason);
        return `stripped of ${roles.size} dangerous role(s)`;
      }
      // Nothing removable (e.g. a bot with a managed role): fall back to kicking.
      if (member.kickable) { await member.kick(reason); return 'kicked (no removable roles)'; }
    }
  } catch (err) {
    logger.warn(`Security action failed for ${member.id}: ${err.message}`);
  }
  return null;
}

// ---- joins: unwanted bots and alts -----------------------------------------------------------

async function findExecutor(guild, type, targetId, attempts = 2) {
  if (!guild.members.me?.permissions.has(P.ViewAuditLog)) return null;
  for (let i = 0; i < attempts; i++) {
    try {
      const logs = await guild.fetchAuditLogs({ type, limit: 6 });
      const entry = logs.entries.find((e) => (!targetId || e.target?.id === targetId) && Date.now() - e.createdTimestamp < 15_000);
      if (entry) return entry.executor ?? null;
    } catch (err) {
      logger.debug(`Audit log lookup failed: ${err.message}`);
      return null;
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  return null;
}

/** Called for every new member (after anti-raid). Returns true when the member was removed. */
async function handleJoin(member) {
  const { guild } = member;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled) return false;

  if (member.user.bot) {
    if (!cfg.blockBots) return false;
    const adder = await findExecutor(guild, AuditLogEvent.BotAdd, member.id);
    const adderMember = adder ? await guild.members.fetch(adder.id).catch(() => null) : null;
    if (adder && isTrusted(guild, adderMember, adder.id)) return false;
    const who = adder ? `<@${adder.id}>` : 'someone I could not identify';
    const result = await punish(member, 'kick', 'Security: bot added by an untrusted member');
    await alert(guild, `Bot **${member.user.tag}** was added by ${who}. Result: **${result ?? 'could not remove it'}**.\nTrusted members (server owner or a \`trusted_role\`) may add bots.`);
    return result !== null;
  }

  const reason = altReason(member.user, cfg);
  if (!reason) return false;
  switch (cfg.altAction) {
    case 'kick': case 'ban': {
      const result = await punish(member, cfg.altAction, `Security: suspected alt (${reason})`);
      await alert(guild, `${member} looks like an alt: ${reason}. Result: **${result ?? 'could not act'}**.`, '🕵️ Alt check');
      return result !== null;
    }
    case 'quarantine': {
      const role = cfg.quarantineRoleId && guild.roles.cache.get(cfg.quarantineRoleId);
      let ok = false;
      if (role && role.position < guild.members.me.roles.highest.position) {
        ok = await member.roles.add(role, `Security: suspected alt (${reason})`).then(() => true, () => false);
      }
      await alert(guild, `${member} looks like an alt: ${reason}. ${ok ? `Given ${role}.` : '**Could not apply the quarantine role** — check `/config security`.'}`, '🕵️ Alt check');
      return false; // stays in the server, so welcome/autorole still run (autorole should not undo quarantine)
    }
    default:
      await alert(guild, `${member} looks like an alt: ${reason}. Review them manually.`, '🕵️ Alt check');
      return false;
  }
}

// ---- anti-nuke -------------------------------------------------------------------------------

const destructive = new Counter();
const flagged = new Map(); // `${guild}:${executor}` -> until timestamp (channels are restored while flagged)
const FLAG_MS = 5 * 60_000;

/**
 * Registers one destructive action by `executor`. Punishes when the limit is reached.
 * @returns {Promise<boolean>} true when the executor is (now) considered a nuker.
 */
async function registerDestructive(guild, executor, what) {
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.nukeProtection || !executor) return false;
  const member = await guild.members.fetch(executor.id).catch(() => null);
  if (isTrusted(guild, member, executor.id)) return false;

  const key = `${guild.id}:${executor.id}`;
  if ((flagged.get(key) ?? 0) > Date.now()) return true;
  const n = destructive.hit(key, cfg.nukeSeconds * 1000);
  if (n < cfg.nukeLimit) return false;

  flagged.set(key, Date.now() + FLAG_MS);
  destructive.clear(key);
  let result = null;
  const why = `Security: ${n} destructive actions in ${cfg.nukeSeconds}s (${what})`;
  if (member) result = await punish(member, cfg.nukeAction, why);
  else if (cfg.nukeAction === 'ban') {
    // Already left the server (or not cached): a ban by id still works.
    result = await guild.members.ban(executor.id, { reason: why }).then(() => 'banned (permanent)', () => null);
  }
  await alert(guild, `${executor} did **${n}** destructive actions within ${cfg.nukeSeconds}s (last: ${what}).\nAction \`${cfg.nukeAction}\`: **${result ?? 'could not act (check my role position and permissions)'}**.${cfg.restoreChannels ? '\nDeleted channels are being restored (messages cannot be).' : ''}\nIf more was lost, use \`/config backup action:restore\` (see \`action:list\`).`, '🚨 Anti-nuke');
  return true;
}

/** Re-creates a deleted channel (same name, type, category, topic and permissions). Messages are gone for good. */
async function restoreChannel(channel) {
  const guild = channel.guild;
  try {
    const supported = [ChannelType.GuildText, ChannelType.GuildVoice, ChannelType.GuildAnnouncement, ChannelType.GuildCategory];
    if (!supported.includes(channel.type)) return null;
    return await guild.channels.create({
      name: channel.name,
      type: channel.type,
      parent: channel.parentId ?? undefined,
      topic: channel.topic ?? undefined,
      nsfw: channel.nsfw,
      rateLimitPerUser: channel.rateLimitPerUser,
      bitrate: channel.type === ChannelType.GuildVoice ? channel.bitrate : undefined,
      userLimit: channel.type === ChannelType.GuildVoice ? channel.userLimit : undefined,
      position: channel.rawPosition,
      permissionOverwrites: channel.permissionOverwrites.cache.map((o) => ({ id: o.id, type: o.type, allow: o.allow, deny: o.deny })),
      reason: 'Security: restoring a channel deleted during a nuke attempt',
    });
  } catch (err) {
    logger.warn(`Channel restore failed: ${err.message}`);
    return null;
  }
}

async function onChannelDelete(channel) {
  const guild = channel.guild;
  if (!guild) return;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.nukeProtection) return;
  const executor = await findExecutor(guild, AuditLogEvent.ChannelDelete, channel.id);
  if (!executor || executor.id === guild.client.user.id) return; // the bot's own deletions (/nuke, temp voice, tickets) are fine
  const nuker = await registerDestructive(guild, executor, `deleted #${channel.name}`);
  if (nuker && cfg.restoreChannels) await restoreChannel(channel);
}

async function onRoleDelete(role) {
  const guild = role.guild;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.nukeProtection) return;
  const executor = await findExecutor(guild, AuditLogEvent.RoleDelete, role.id);
  if (!executor || executor.id === guild.client.user.id) return;
  await registerDestructive(guild, executor, `deleted role @${role.name}`);
}

async function onBan(ban) {
  const guild = ban.guild;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.nukeProtection) return;
  const executor = await findExecutor(guild, AuditLogEvent.MemberBanAdd, ban.user.id);
  if (!executor || executor.id === guild.client.user.id) return;
  await registerDestructive(guild, executor, `banned ${ban.user.tag}`);
}

async function onMemberRemove(member) {
  const guild = member.guild;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.nukeProtection) return;
  const executor = await findExecutor(guild, AuditLogEvent.MemberKick, member.id, 1);
  if (!executor || executor.id === guild.client.user.id) return;
  await registerDestructive(guild, executor, `kicked ${member.user.tag}`);
}

// ---- bot spam ---------------------------------------------------------------------------------

const botMessages = new Counter();

/** Messages from bots that are not me: too many too fast gets the bot removed and its flood deleted. */
async function onBotMessage(message) {
  const { guild } = message;
  if (!guild || !message.author.bot || message.webhookId || message.author.id === guild.client.user.id) return;
  const cfg = cfgOf(guild.id);
  if (!cfg.enabled || !cfg.botSpam) return;
  const key = `${guild.id}:${message.author.id}`;
  const n = botMessages.hit(key, cfg.botSpamSeconds * 1000);
  if (n < cfg.botSpamLimit) return;
  botMessages.clear(key);
  const member = message.member ?? await guild.members.fetch(message.author.id).catch(() => null);
  if (!member || isTrusted(guild, member, member.id)) return;
  const result = await punish(member, 'kick', `Security: bot spam (${n} messages in ${cfg.botSpamSeconds}s)`);
  if (message.channel.permissionsFor(guild.members.me)?.has(P.ManageMessages)) {
    const recent = await message.channel.messages.fetch({ limit: 50 }).catch(() => null);
    const mine = recent?.filter((m) => m.author.id === member.id && Date.now() - m.createdTimestamp < 14 * 86_400_000);
    if (mine?.size) await message.channel.bulkDelete(mine, true).catch(() => {});
  }
  await alert(guild, `Bot **${message.author.tag}** sent **${n}** messages in ${cfg.botSpamSeconds}s in ${message.channel}. Result: **${result ?? 'could not remove it'}**.`, '🤖 Bot spam');
}

setInterval(() => {
  destructive.sweep(5 * 60_000);
  botMessages.sweep(60_000);
  const now = Date.now();
  for (const [k, t] of flagged) if (t < now) flagged.delete(k);
}, 60_000).unref?.();

module.exports = {
  Counter, altReason, isTrusted, problems, handleJoin, registerDestructive,
  onChannelDelete, onRoleDelete, onBan, onMemberRemove, onBotMessage,
};
