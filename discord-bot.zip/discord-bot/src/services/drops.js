'use strict';

const { PermissionFlagsBits } = require('discord.js');
const db = require('../database');
const settings = require('./settings');
const eco = require('./economy');
const logger = require('../utils/logger');
const { randomInt, pick } = require('../utils/text');

const lastDrop = new Map(); // `${guild}:${user}` -> timestamp
const MAX_PER_HOUR = 20; // per guild, so a busy chat cannot flood the economy
const hourly = new Map(); // guild -> [timestamps]

/** Items that can drop: shop items that are not roles. */
const droppableItems = (guildId) => eco.listItems(guildId).filter((i) => !i.role_id);

/** Decides and applies a reward. Returns { kind: 'coins'|'item', amount?, item? }. */
function roll(guildId, userId, cfg, random = Math.random) {
  const items = droppableItems(guildId);
  if (items.length && random() < cfg.itemChance) {
    const item = pick(items);
    eco.grantItem(guildId, userId, item, 1);
    return { kind: 'item', item };
  }
  const amount = randomInt(cfg.minCoins, cfg.maxCoins);
  eco.adjust(guildId, userId, { wallet: amount }, 'drop', 'random drop');
  return { kind: 'coins', amount };
}

/** Called for every normal guild message (never for chat commands). */
async function handleMessage(message, random = Math.random) {
  if (!message.guild || message.author.bot || message.webhookId) return null;
  const g = message.guild.id;
  const s = settings.view(g);
  if (!s.drops.enabled || !s.economy.enabled) return null;
  const cfg = s.drops;
  if (cfg.channelIds.length && !cfg.channelIds.includes(message.channelId)) return null;
  if (message.content.length < cfg.minMessageLength) return null;
  if (random() >= cfg.chance) return null;

  const key = `${g}:${message.author.id}`;
  const now = Date.now();
  if (now - (lastDrop.get(key) ?? 0) < cfg.userCooldownSeconds * 1000) return null;
  const recent = (hourly.get(g) ?? []).filter((t) => now - t < 3_600_000);
  if (recent.length >= MAX_PER_HOUR) return null;
  recent.push(now);
  hourly.set(g, recent);
  lastDrop.set(key, now);

  const reward = roll(g, message.author.id, cfg, random);
  const text = reward.kind === 'item'
    ? `🎁 <@${message.author.id}> found **${reward.item.name}**! It is in your inventory.`
    : `🎁 <@${message.author.id}> found ${eco.money(g, reward.amount)}! It is in your wallet.`;

  const me = message.guild.members.me;
  if (message.channel.permissionsFor(me)?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages])) {
    try {
      const note = await message.channel.send({ content: text, allowedMentions: { users: [message.author.id] } });
      setTimeout(() => note.delete().catch(() => {}), cfg.deleteAfterSeconds * 1000).unref?.();
    } catch (err) {
      logger.debug(`Drop notice failed: ${err.message}`);
    }
  }
  return reward;
}

setInterval(() => {
  const now = Date.now();
  for (const [k, t] of lastDrop) if (now - t > 86_400_000) lastDrop.delete(k);
}, 30 * 60_000).unref?.();

module.exports = { handleMessage, roll, droppableItems };
