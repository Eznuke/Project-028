'use strict';

const db = require('../database');
const config = require('../config');
const prefix = require('./prefix');
const embeds = require('../utils/embeds');
const audit = require('./audit');
const { UserError } = require('../utils/errors');
const { confirm } = require('../utils/confirm');
const { checkCooldown, checkGlobal } = require('../utils/ratelimit');
const { fill, memberPlaceholders, truncate } = require('../utils/text');
const { ts } = require('../utils/time');

const MAX_PER_GUILD = 25;
const MAX_RESPONSE = 1500;
const NAME_RE = /^[a-z0-9_-]{1,32}$/;
const COOLDOWN_SECONDS = 3; // per member and command, so one command cannot be used to flood a channel

const get = (guildId, name) => db.get('SELECT * FROM custom_commands WHERE guild_id = ? AND name = ?', guildId, String(name).toLowerCase());
const list = (guildId) => db.all('SELECT * FROM custom_commands WHERE guild_id = ? ORDER BY name', guildId);
const count = (guildId) => db.get('SELECT COUNT(*) AS n FROM custom_commands WHERE guild_id = ?', guildId).n;

/** "\n" typed into a slash option becomes a real line break. */
const normalize = (text) => String(text).replace(/\\n/g, '\n').trim();

function validateName(raw, commands) {
  const name = String(raw ?? '').trim().toLowerCase().replace(/^[^a-z0-9_-]+/, '');
  if (!NAME_RE.test(name)) throw new UserError('The name can only use letters, numbers, `-` and `_` (1-32 characters), without the prefix.');
  if (commands && prefix.findCommand(commands, name)) throw new UserError(`\`${name}\` is already a built-in command (or alias), so it cannot be used as a custom command.`);
  return name;
}

function validateResponse(raw) {
  const text = normalize(raw);
  if (!text) throw new UserError('The response cannot be empty.');
  if (text.length > MAX_RESPONSE) throw new UserError(`The response can have at most ${MAX_RESPONSE} characters (you wrote ${text.length}).`);
  return text;
}

function add(guildId, name, response, { embed = false, userId = null } = {}) {
  if (get(guildId, name)) throw new UserError(`\`${name}\` already exists. Use \`action:edit\` to change it.`);
  if (count(guildId) >= MAX_PER_GUILD) throw new UserError(`This server already has ${MAX_PER_GUILD} custom commands (the maximum). Remove one first.`);
  const now = Date.now();
  db.run(
    'INSERT INTO custom_commands (guild_id, name, response, use_embed, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    guildId, name, response, embed ? 1 : 0, userId, now, now,
  );
}

function edit(guildId, name, { response, embed }) {
  const row = get(guildId, name);
  if (!row) throw new UserError(`There is no custom command called \`${name}\`.`);
  db.run(
    'UPDATE custom_commands SET response = ?, use_embed = ?, updated_at = ? WHERE guild_id = ? AND name = ?',
    response ?? row.response, embed === undefined || embed === null ? row.use_embed : (embed ? 1 : 0), Date.now(), guildId, name,
  );
}

const remove = (guildId, name) => db.run('DELETE FROM custom_commands WHERE guild_id = ? AND name = ?', guildId, name).changes > 0;

/** The message payload for one use of a command. Mentions are limited to the member who used it. */
function render(row, message, args) {
  const member = message.member;
  const values = {
    ...(member ? memberPlaceholders(member) : { user: `<@${message.author.id}>`, username: message.author.username, tag: message.author.username, id: message.author.id, server: message.guild?.name ?? '', memberCount: '' }),
    channel: `<#${message.channelId}>`,
    args: args || '',
  };
  const text = truncate(fill(row.response, values), 2000, '…');
  const allowedMentions = { users: [message.author.id], parse: [], repliedUser: false };
  return row.use_embed ? { embeds: [embeds.info(truncate(text, 4000))], allowedMentions } : { content: text, allowedMentions };
}

/** Same silent gates as built-in chat commands: blacklist, maintenance, rate limits. */
function mayRun(client, userId, name) {
  if (config.isOwner(userId)) return true;
  if (db.get('SELECT 1 AS x FROM blacklist WHERE user_id = ?', userId)) return false;
  if (client.maintenance) return false;
  if (checkGlobal(userId, config.globalRateLimit) > 0) return false;
  return checkCooldown(`custom:${name}`, userId, COOLDOWN_SECONDS) === 0;
}

// ---- /config customcommand -------------------------------------------------------------------

function addOptions(sub) {
  return sub
    .addStringOption((o) => o.setName('action').setDescription('What to do').setRequired(true)
      .addChoices(...['add', 'edit', 'remove', 'list', 'info'].map((a) => ({ name: a, value: a }))))
    .addStringOption((o) => o.setName('name').setDescription('Command name without the prefix, e.g. rules').setMaxLength(33))
    .addStringOption((o) => o.setName('response').setDescription('Reply text. {user} {username} {server} {channel} {args}; \\n = new line').setMaxLength(MAX_RESPONSE))
    .addBooleanOption((o) => o.setName('embed').setDescription('Send the reply as an embed (default: plain text)'));
}

async function run(interaction) {
  const g = interaction.guildId;
  const action = interaction.options.getString('action', true);
  const ephemeral = { flags: 64, allowedMentions: { parse: [] } };
  const p = prefix.prefixSettings(g);
  const lead = p.enabled ? p.value : '!';

  if (action === 'list') {
    const rows = list(g);
    const text = rows.length
      ? rows.map((r) => `\`${lead}${r.name}\` · ${r.use_embed ? 'embed' : 'text'} · ${r.uses} uses`).join('\n')
      : 'No custom commands yet. Add one with `/config customcommand action:add name:rules response:"Be kind."`.';
    await interaction.reply({ embeds: [embeds.base(`✨ Custom commands (${rows.length}/${MAX_PER_GUILD})`, `${text}${p.enabled ? '' : '\n\n⚠️ Chat commands are switched off here, so custom commands cannot be used. Turn them on with `/config prefix enabled:true`.'}`)], ...ephemeral });
    return;
  }

  if (!interaction.options.getString('name')) throw new UserError('Give the command name with `name:`.');
  const name = validateName(interaction.options.getString('name'), action === 'add' ? interaction.client.commands : null);

  if (action === 'info') {
    const row = get(g, name);
    if (!row) throw new UserError(`There is no custom command called \`${name}\`.`);
    await interaction.reply({
      embeds: [embeds.base(`✨ ${lead}${row.name}`, `${truncate(row.response, 1500)}`).addFields(
        { name: 'Type', value: row.use_embed ? 'Embed' : 'Plain text', inline: true },
        { name: 'Used', value: `${row.uses}×`, inline: true },
        { name: 'Last changed', value: ts(row.updated_at, 'R'), inline: true },
      )],
      ...ephemeral,
    });
    return;
  }

  if (action === 'remove') {
    if (!get(g, name)) throw new UserError(`There is no custom command called \`${name}\`.`);
    const ok = await confirm(interaction, { description: `Delete the custom command \`${lead}${name}\`?`, confirmLabel: 'Delete' });
    if (!ok) return;
    remove(g, name);
    audit.record(g, interaction.user.id, 'customcommand.remove', name);
    await interaction.editReply({ embeds: [embeds.success(`Deleted \`${lead}${name}\`.`)], components: [] });
    return;
  }

  const embed = interaction.options.getBoolean('embed');
  if (action === 'add') {
    const response = validateResponse(interaction.options.getString('response'));
    add(g, name, response, { embed: embed ?? false, userId: interaction.user.id });
    audit.record(g, interaction.user.id, 'customcommand.add', name);
    await interaction.reply({ embeds: [embeds.success(`Created \`${lead}${name}\` (${count(g)}/${MAX_PER_GUILD}). Try it: \`${lead}${name}\`${p.enabled ? '' : '\n⚠️ Chat commands are off in this server; turn them on with `/config prefix enabled:true`.'}`)], ...ephemeral });
    return;
  }

  // edit
  const raw = interaction.options.getString('response');
  if (!raw && embed === null) throw new UserError('Give a new `response:` and/or `embed:` to change.');
  edit(g, name, { response: raw ? validateResponse(raw) : undefined, embed });
  audit.record(g, interaction.user.id, 'customcommand.edit', name);
  await interaction.reply({ embeds: [embeds.success(`Updated \`${lead}${name}\`.`)], ...ephemeral });
}

module.exports = { MAX_PER_GUILD, get, list, count, add, edit, remove, render, mayRun, validateName, validateResponse, addOptions, run };
