'use strict';

const settings = require('../services/settings');
const backups = require('../services/backups');
const logger = require('../utils/logger');

/** Automatic server backups for servers that turned `auto_backup` on in /config security. */
module.exports = {
  name: 'backups',
  intervalMs: 30 * 60_000,
  async run(client) {
    for (const guild of client.guilds.cache.values()) {
      const cfg = settings.view(guild.id).security;
      if (!cfg.autoBackup) continue;
      const last = backups.latestAuto(guild.id)?.created_at ?? 0;
      if (Date.now() - last < cfg.backupHours * 3_600_000) continue;
      try {
        await backups.create(guild, { kind: 'auto', name: 'Automatic backup' });
      } catch (err) {
        logger.warn(`Automatic backup failed for ${guild.id}: ${err.message}`);
      }
    }
  },
};
