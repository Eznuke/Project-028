'use strict';

const { Events } = require('discord.js');
const security = require('../services/security');
const logger = require('../utils/logger');

const safe = (fn, label) => async (...args) => {
  try { await fn(...args.slice(0, -1)); } catch (err) { logger.warn(`Security (${label}) failed: ${err.message}`); }
};

// Each handler receives (...eventArgs, client); the client is dropped before calling the service.
module.exports = [
  { name: Events.ChannelDelete, execute: safe(security.onChannelDelete, 'channelDelete') },
  { name: Events.GuildRoleDelete, execute: safe(security.onRoleDelete, 'roleDelete') },
  { name: Events.GuildBanAdd, execute: safe(security.onBan, 'ban') },
  { name: Events.GuildMemberRemove, execute: safe(security.onMemberRemove, 'memberRemove') },
  { name: Events.MessageCreate, execute: safe(security.onBotMessage, 'botSpam') },
];
