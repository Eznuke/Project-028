'use strict';

// Entry file for hosts that always start "index.js" (for example bot-hosting.net).
require('./src/index.js');
